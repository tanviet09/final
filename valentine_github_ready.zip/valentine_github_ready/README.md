# Website lời mời đi chơi — GitHub Pages

## Nội dung
- `index.html`: website hoàn chỉnh một trang, CSS và JavaScript được nhúng trong file.
- `food/`: ảnh món ăn và món tráng miệng.
- `activities/`: ảnh hoạt động.
- `cat.gif`, `valentines-icegif-5.gif`: ảnh GIF.
- `congratulations.mp3`: nhạc từ dự án gốc (không tự phát để tránh bị trình duyệt chặn; có thể bổ sung nút phát nếu muốn).

## Đưa lên GitHub Pages
1. Giải nén toàn bộ thư mục này.
2. Mở repository GitHub của bạn.
3. Tải **toàn bộ nội dung bên trong thư mục** lên nhánh `main` (đừng chỉ tải riêng `index.html`, vì ảnh nằm trong các thư mục `food/` và `activities/`).
4. Đảm bảo `index.html` nằm ở thư mục gốc repository.
5. Mở Settings → Pages.
6. Chọn Deploy from a branch → `main` → `/(root)` → Save.
7. Mở Actions và chờ quá trình triển khai hoàn tất, sau đó truy cập URL Pages của repository.

## Chỉnh sửa thông tin cá nhân
Mở `index.html` bằng VS Code hoặc Notepad++ và dùng Ctrl+F để tìm:

- `senderName: "Việt"`: tên người gửi trong chữ ký.
- `Chị đi chơi với em nhé?`: tiêu đề lời mời.
- `Cuối tuần này, em rất mong...`: đoạn lời mời.
- `18:30`: giờ mặc định.
- `Địa điểm dự kiến`: nhãn địa điểm; placeholder ở input có thể sửa trực tiếp trong HTML.
- `zaloPhone: ""`: điền số Zalo theo dạng mã quốc gia, bỏ số 0 đầu; ví dụ `0901234567` thành `84901234567`. Để `""` nếu không muốn hiện nút Zalo.
- `heartsEnabled: true`: đổi thành `false` để tắt tim bay.
- Mã màu trong `:root` ở đầu CSS: `--pink`, `--pink-dark`, `--pink-soft`.
- Nội dung món ăn: tìm `data-value="..."` và nhãn kế bên.
- Ảnh: sửa `src="food/..."` hoặc `src="activities/..."` và bảo đảm tên file khớp chính xác.

## Quan trọng về đường dẫn GitHub Pages
Các ảnh dùng đường dẫn tương đối như `food/pizza.jpeg`, nên hoạt động ở cả URL dạng project site `/ten-repository/` và domain riêng. Giữ nguyên cấu trúc thư mục khi tải lên.

## Hạn chế
GitHub Pages là hosting tĩnh. Những lựa chọn ngày, món ăn và hoạt động chỉ được tổng hợp trong trình duyệt người xem; website không tự gửi chúng về cho chủ trang. Nút Zalo chỉ mở trang Zalo, không tự gửi tin nhắn.
